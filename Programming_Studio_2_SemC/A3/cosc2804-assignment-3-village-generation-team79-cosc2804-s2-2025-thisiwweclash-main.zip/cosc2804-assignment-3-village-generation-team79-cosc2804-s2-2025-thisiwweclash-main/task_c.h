#ifndef TASK_C
#define TASK_C

#include <vector>
#include <iostream>
#include "plots.h"
#include "paths.h"

void connect_waypoints() ;

void connect_buildings() ;

#endif