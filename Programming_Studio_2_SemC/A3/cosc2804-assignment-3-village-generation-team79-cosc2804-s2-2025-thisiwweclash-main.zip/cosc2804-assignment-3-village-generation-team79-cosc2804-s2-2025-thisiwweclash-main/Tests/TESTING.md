# Task A:
## Component 1 - {Component name}
**Test 1**: Test name
**Description**: {Description}
**Setup**: {arguments} {other details needed to setup the test}
**Expected Output**: {Criteria}


# Task B:
## Component 1 - {Component name}
**Test 1**: Test name
**Description**: {Description}
**Setup**: {arguments} {other details needed to setup the test}
**Expected Output**: {Criteria}


# Task C:
## Component 1 - {Component name}
**Test 1**: Test name
**Description**: {Description}
**Setup**: {arguments} {other details needed to setup the test}
**Expected Output**: {Criteria}

# Example Test:
## Task B Subdividing Building:
**Test 1**: Normal Usage:
**Description**: Testing a normal use case for recursive subdivision.
**Setup**: loc=123,123 village-size=50, plot-border=10, seed=1, testmode
(123,123) should be within superflat terrain, to ensure no environmental disruptions.
**Expected output**
XXXXXXXXXXXXXXXXXXXXX
X    X    X    X    X
X    .    .    .    X
X    X    X    X    X
X    X    X    X    X
XXX.XXXX.XXXX.XXXX.XX
X    X    X    X    X
X    X    X    X    X
X    X    X    X    X
X    X    X    X    X
XXX.XXXX.XXXX.XXXX.XX
X    X    X    X    X
X    X    X    X    X
X    X    X    X    X
X    X    X    X    X
XXX.XXXX.XXXX.XXXX.XX
X    X    X    X    X
X    .    .    .    X
X    X    X    X    X
X    X    X    X    X
XXXXXXXXXXXXXXXXXXXXX
