[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/L2RIlY3N)
# COSC2804_2502_A3

## Team Members

Task A. {Full Name} - {Student Email} - {GitHub Username}

Task B. {Full Name} - {Student Email} - {GitHub Username}

Task C. {Full Name} - {Student Email} - {GitHub Username}

## Video
{Video Link}

## Contributions
Student #1 - {Full Name}:
1. Component
2. Component
3. etc

Student #2 - {Full Name}:
1. Component
2. Component
3. etc

Student #3 - {Full Name}:
1. Component
2. Component
3. etc
