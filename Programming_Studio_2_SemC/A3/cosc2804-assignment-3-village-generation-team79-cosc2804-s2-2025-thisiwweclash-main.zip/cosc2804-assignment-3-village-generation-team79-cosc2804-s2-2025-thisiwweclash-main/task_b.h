#ifndef TASK_B
#define TASK_B

#include <vector>
#include <iostream>
#include "plots.h"

void build_buildings() ;


#endif