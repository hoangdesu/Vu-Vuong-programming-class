## Examples
A few small examples to show the capabilities of `mcpp`.

They should be compilable with something along the lines of `g++ -std=c++17 -o example example.cpp -lmcpp`  
after you have installed the library.

Feel free to open a PR if you have an interesting usecase to include as part of the examples.
