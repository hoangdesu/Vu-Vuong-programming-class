#include "task_c.h"

void connect_waypoints() {

}

void connect_buildings() {
    
}