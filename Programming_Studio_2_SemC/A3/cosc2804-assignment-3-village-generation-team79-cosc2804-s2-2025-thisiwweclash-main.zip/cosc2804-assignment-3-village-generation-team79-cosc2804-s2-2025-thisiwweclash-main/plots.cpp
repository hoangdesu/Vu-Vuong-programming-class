#include "plots.h"

Plot::Plot(mcpp::Coordinate origin, mcpp::Coordinate bound, mcpp::Coordinate entrance)
    : origin(origin), bound(bound), entrance(entrance) {}
