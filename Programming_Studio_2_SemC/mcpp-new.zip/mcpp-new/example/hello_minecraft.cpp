#include <mcpp/mcpp.h>

using namespace mcpp;

int main() {
  MinecraftConnection mc;

  // Post chat to Minecraft
  mc.postToChat("Hello, Minecraft!");
}
